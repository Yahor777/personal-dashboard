import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerTrigger } from "../ui/drawer";
import { Textarea } from "../ui/textarea";
import { Label } from "../ui/label";
import { Progress } from "../ui/progress";
import { Search, Filter, Plus, Paperclip, Calendar, Tag } from "lucide-react";
import { motion } from "motion/react";

interface Task {
  id: string;
  title: string;
  description: string;
  tags: string[];
  priority: "high" | "medium" | "low";
  progress: number;
  date: string;
  attachments: number;
  column: "todo" | "progress" | "done";
}

const initialTasks: Task[] = [
  {
    id: "1",
    title: "Изучить React Hooks",
    description: "Пройти документацию и примеры",
    tags: ["React", "JavaScript"],
    priority: "high",
    progress: 30,
    date: "2025-11-05",
    attachments: 2,
    column: "todo",
  },
  {
    id: "2",
    title: "Настроить Tailwind CSS",
    description: "Конфигурация и кастомизация",
    tags: ["CSS", "Design"],
    priority: "medium",
    progress: 60,
    date: "2025-11-03",
    attachments: 1,
    column: "progress",
  },
  {
    id: "3",
    title: "Создать API для проекта",
    description: "REST API с аутентификацией",
    tags: ["Backend", "API"],
    priority: "high",
    progress: 85,
    date: "2025-11-01",
    attachments: 3,
    column: "progress",
  },
  {
    id: "4",
    title: "Написать тесты",
    description: "Unit и интеграционные тесты",
    tags: ["Testing", "Quality"],
    priority: "low",
    progress: 100,
    date: "2025-10-28",
    attachments: 0,
    column: "done",
  },
];

const columns = [
  { id: "todo", title: "К изучению", color: "bg-blue-500/10 border-blue-500/20" },
  { id: "progress", title: "В процессе", color: "bg-yellow-500/10 border-yellow-500/20" },
  { id: "done", title: "Выполнено", color: "bg-green-500/10 border-green-500/20" },
];

export function TasksKanban() {
  const [tasks, setTasks] = useState(initialTasks);
  const [searchQuery, setSearchQuery] = useState("");
  const [priorityFilter, setPriorityFilter] = useState<string>("all");
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const filteredTasks = tasks.filter((task) => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPriority = priorityFilter === "all" || task.priority === priorityFilter;
    return matchesSearch && matchesPriority;
  });

  const handleDragStart = (e: React.DragEvent, taskId: string) => {
    e.dataTransfer.setData("taskId", taskId);
  };

  const handleDrop = (e: React.DragEvent, columnId: string) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData("taskId");
    setTasks((prev) =>
      prev.map((task) =>
        task.id === taskId ? { ...task, column: columnId as Task["column"] } : task
      )
    );
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive";
      case "medium":
        return "default";
      case "low":
        return "secondary";
      default:
        return "secondary";
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Канбан Доска</h1>
          <p className="text-muted-foreground">Управляйте задачами с помощью drag & drop</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Новая задача
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Поиск задач..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger className="w-48">
            <Filter className="mr-2 h-4 w-4" />
            <SelectValue placeholder="Приоритет" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все приоритеты</SelectItem>
            <SelectItem value="high">Высокий</SelectItem>
            <SelectItem value="medium">Средний</SelectItem>
            <SelectItem value="low">Низкий</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Kanban Board */}
      <div className="grid gap-6 lg:grid-cols-3">
        {columns.map((column) => (
          <div key={column.id} className="space-y-4">
            <Card className={column.color}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  {column.title}
                  <Badge variant="secondary">
                    {filteredTasks.filter((t) => t.column === column.id).length}
                  </Badge>
                </CardTitle>
              </CardHeader>
            </Card>

            <div
              className="space-y-3 min-h-[400px]"
              onDrop={(e) => handleDrop(e, column.id)}
              onDragOver={handleDragOver}
            >
              {filteredTasks
                .filter((task) => task.column === column.id)
                .map((task, index) => (
                  <Drawer key={task.id}>
                    <DrawerTrigger asChild>
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                        draggable
                        onDragStart={(e) => handleDragStart(e, task.id)}
                        className="cursor-move"
                        onClick={() => setSelectedTask(task)}
                      >
                        <Card className="transition-shadow hover:shadow-lg">
                          <CardContent className="space-y-3 p-4">
                            <div className="flex items-start justify-between">
                              <h4>{task.title}</h4>
                              <Badge variant={getPriorityColor(task.priority)}>
                                {task.priority}
                              </Badge>
                            </div>
                            <p className="text-muted-foreground">{task.description}</p>
                            <div className="flex flex-wrap gap-1">
                              {task.tags.map((tag) => (
                                <Badge key={tag} variant="outline">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <span className="text-muted-foreground">Прогресс</span>
                                <span>{task.progress}%</span>
                              </div>
                              <Progress value={task.progress} />
                            </div>
                            <div className="flex items-center justify-between text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                <span>{task.date}</span>
                              </div>
                              {task.attachments > 0 && (
                                <div className="flex items-center gap-1">
                                  <Paperclip className="h-4 w-4" />
                                  <span>{task.attachments}</span>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    </DrawerTrigger>
                    <DrawerContent>
                      <DrawerHeader>
                        <DrawerTitle>Редактировать задачу</DrawerTitle>
                      </DrawerHeader>
                      <div className="space-y-4 p-4">
                        <div className="space-y-2">
                          <Label>Название</Label>
                          <Input value={task.title} />
                        </div>
                        <div className="space-y-2">
                          <Label>Описание</Label>
                          <Textarea value={task.description} />
                        </div>
                        <div className="grid gap-4 sm:grid-cols-2">
                          <div className="space-y-2">
                            <Label>Приоритет</Label>
                            <Select value={task.priority}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="high">Высокий</SelectItem>
                                <SelectItem value="medium">Средний</SelectItem>
                                <SelectItem value="low">Низкий</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label>Дата</Label>
                            <Input type="date" value={task.date} />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label>Теги</Label>
                          <Input placeholder="Введите теги через запятую" />
                        </div>
                        <Button className="w-full">Сохранить изменения</Button>
                      </div>
                    </DrawerContent>
                  </Drawer>
                ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
