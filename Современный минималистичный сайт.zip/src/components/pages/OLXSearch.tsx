import { useState } from "react";
import { Card, CardContent } from "../ui/card";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { Badge } from "../ui/badge";
import { Skeleton } from "../ui/skeleton";
import { Search, MapPin, Clock, Heart, Star, SlidersHorizontal } from "lucide-react";
import { motion } from "motion/react";

const mockResults = [
  { id: 1, title: "RTX 4070 Ti Gaming", price: "₽55,000", location: "Москва", date: "Сегодня 14:30", image: "computer hardware", featured: true },
  { id: 2, title: "Intel Core i7-13700K", price: "₽38,000", location: "Санкт-Петербург", date: "Вчера 18:20", image: "computer processor", featured: false },
  { id: 3, title: "DDR5 32GB RAM Kit", price: "₽12,500", location: "Москва", date: "2 дня назад", image: "computer memory", featured: true },
  { id: 4, title: "Монитор 27\" 165Hz", price: "₽28,000", location: "Казань", date: "3 дня назад", image: "computer monitor", featured: false },
  { id: 5, title: "Corsair 850W PSU", price: "₽9,800", location: "Екатеринбург", date: "4 дня назад", image: "power supply", featured: false },
  { id: 6, title: "Samsung 980 PRO 2TB", price: "₽14,500", location: "Москва", date: "5 дней назад", image: "storage drive", featured: true },
];

export function OLXSearch() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState(mockResults);
  const [favorites, setFavorites] = useState<number[]>([]);

  const handleSearch = () => {
    setIsLoading(true);
    setTimeout(() => {
      setResults(mockResults);
      setIsLoading(false);
    }, 1000);
  };

  const toggleFavorite = (id: number) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((fid) => fid !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1>OLX Поиск</h1>
        <p className="text-muted-foreground">Поиск объявлений с расширенными фильтрами</p>
      </div>

      {/* Search Bar */}
      <Card>
        <CardContent className="space-y-4 pt-6">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Что вы ищете?"
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              />
            </div>
            <Button onClick={handleSearch}>Поиск</Button>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Select defaultValue="all">
              <SelectTrigger>
                <SelectValue placeholder="Категория" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все категории</SelectItem>
                <SelectItem value="electronics">Электроника</SelectItem>
                <SelectItem value="computers">Компьютеры</SelectItem>
                <SelectItem value="phones">Телефоны</SelectItem>
              </SelectContent>
            </Select>

            <Input placeholder="Мин. цена" type="number" />
            <Input placeholder="Макс. цена" type="number" />

            <Select defaultValue="newest">
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Новые</SelectItem>
                <SelectItem value="price-low">Цена: низкая</SelectItem>
                <SelectItem value="price-high">Цена: высокая</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-2">
              <SlidersHorizontal className="h-4 w-4" />
              Расширенные фильтры
            </Button>
            <Button variant="outline" size="sm">
              Сохранить поиск
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div>
        <div className="mb-4 flex items-center justify-between">
          <span className="text-muted-foreground">Найдено: {results.length} объявлений</span>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">Избранное ({favorites.length})</Button>
            <Button variant="outline" size="sm">Сохранённые поиски</Button>
          </div>
        </div>

        {isLoading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <CardContent className="space-y-3 p-4">
                  <Skeleton className="h-48 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {results.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="group overflow-hidden transition-shadow hover:shadow-lg">
                  <div className="relative aspect-video overflow-hidden bg-muted">
                    <div className="flex h-full items-center justify-center text-muted-foreground">
                      {item.image}
                    </div>
                    {item.featured && (
                      <Badge className="absolute left-2 top-2 gap-1">
                        <Star className="h-3 w-3" />
                        Топ
                      </Badge>
                    )}
                    <Button
                      size="icon"
                      variant="secondary"
                      className="absolute right-2 top-2 opacity-0 transition-opacity group-hover:opacity-100"
                      onClick={() => toggleFavorite(item.id)}
                    >
                      <Heart
                        className={`h-4 w-4 ${
                          favorites.includes(item.id) ? "fill-current text-red-500" : ""
                        }`}
                      />
                    </Button>
                  </div>
                  <CardContent className="space-y-2 p-4">
                    <h4 className="line-clamp-1">{item.title}</h4>
                    <div className="flex items-center justify-between">
                      <span className="text-green-500">{item.price}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      <span>{item.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>{item.date}</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
